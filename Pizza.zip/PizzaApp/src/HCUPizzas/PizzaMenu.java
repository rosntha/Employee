package HCUPizzas;

import java.util.Scanner;

public class PizzaMenu {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//Pizza p1=new Pizza();
		Veg veg=new Veg();
		//NonVeg nonveg=new NonVeg();
		int choice;
		String category,size,type;
		float cost;
		//double amount,deposit,withdraw;
		/*do {
		System.out.println("1. Veg Pizza");
		System.out.println("2. NonVeg Pizza");
		System.out.println("3. E X I T");
		System.out.println("Enter your choice");
		choice=sc.nextInt();
		switch(choice) {
		case 1: */
			System.out.println("Your Category is Pizza(Veg,NonVeg)");
			category=sc.next();
			System.out.println("Your Choice is Veg Pizza(Small,Medium,Large)");
			System.out.println("Which of size of pizza:");
			size=sc.next();
			System.out.println("Which type of pizza you want? (VegStuffed,VegNotStuffed)");
			type=sc.next();
			//System.out.println("the size is " +size+ "\n");
			if(veg.validateCategory(category)==true) {
			if(veg.validateSize(size)==true) {
				//System.out.println("Which type of pizza you want? (VegStuffed,VegNotStuffed)");
				//type=sc.next();
				if(veg.validateType(type)==true)
					//System.out.println("the size and type are:" +type);
				{
					//1
					System.out.println("this is executed"+type+size+category);
					cost=veg.identifyCost(type,size);
					System.out.println("the cost is"+cost);
					
				}
			}
			//System.out.println("the cost is"+veg.identifyCost());
			
			}
		//	break;
			

		
	//	}while(choice<3);
		
		}


}
