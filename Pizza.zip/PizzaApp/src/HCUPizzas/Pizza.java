package HCUPizzas;

import java.util.Scanner;

public abstract class Pizza {
	int itemId;
	int billId;
	String category;
	String type;
	String size;
	
	public Pizza() {
		super();
		
	}



	public Pizza(int itemId, int billId, String category, String type, String size) {
		super();
		this.itemId = itemId;
		this.billId = billId;
		this.category = category;
		this.type = type;
		this.size = size;
	}



	public int getItemId() {
		return itemId;
	}



	public void setItemId(int itemId) {
		this.itemId = itemId;
	}



	public int getBillId() {
		return billId;
	}



	public void setBillId(int billId) {
		this.billId = billId;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}



	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}



	public String getSize() {
		return size;
	}



	public void setSize(String size) {
		this.size = size;
	}
	
	
	Scanner sc=new Scanner(System.in);
	public boolean validateCategory(String category) {
		
		//System.out.println("Enter your option (1. Veg 2. NonVeg):" + category);
		//category=sc.next();
		if(category.equalsIgnoreCase("Veg") ||category.equalsIgnoreCase("NonVeg")) {
			System.out.println("this is");
			return true;
		}
		return false;
	}
	public boolean validateSize(String size) {
		System.out.println("size is" +size);
		if(size.equalsIgnoreCase("small")|| size.equalsIgnoreCase("medium")|| size.equalsIgnoreCase("large")) {
			
			return true;
		}
		return false;
		
	}
	
	
	abstract public boolean validateType();
	
	abstract public float identifyCost();
	
	abstract public float calculateBillAmount();

}
