package HCUPizzas;

import java.util.Scanner;

public class NonVeg extends Pizza{
	String nonVegToppings;
	private int id;
	static int counter=1;
	NonVeg nonveg=new NonVeg();
	
	public NonVeg() {
		super();
		
	}




	public NonVeg(String nonVegToppings, int id) {
		super();
		this.nonVegToppings = nonVegToppings;
		this.id = counter++;
	}
	
	//public String getNonVegToppings() {
		
	//}
	
	public boolean validateType(String type) {
		System.out.println("Enter your option (1. NonVegStuffed 2. NonVegNotStuffed):" + type);
		category=sc.next();
		if(type.equalsIgnoreCase("NonVegStuffed") ||  type.equalsIgnoreCase("NonVegNotStuffed")) {
			return true;
		}
		return false;
	}
	
	public float identifyCost(String type,String size) {
		validateType(type);
		validateSize(size);
		float cost=0;
		if(validateSize(size)==true && validateType()==true) {
			//type=nonveg.getType();
			//size=nonveg.getSize();
			if(type.equalsIgnoreCase("VegStuffed") && size.equalsIgnoreCase("Small")) {
				cost=20;
			}
			
		}
		return cost;
		
		
	}
	
	public float calculateBillAmount() {
		nonveg.validateCategory(category);
		float BillAmount=nonveg.identifyCost()+(nonveg.identifyCost()*10)/100;
		System.out.println(BillAmount);
		return BillAmount;
		
	}




	@Override
	public boolean validateType() {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public float identifyCost() {
		// TODO Auto-generated method stub
		return 0;
	}

}
