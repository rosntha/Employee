package HCUPizzas;

public class Veg extends Pizza {
	String vegToppings;
	private int id;
	static int counter=1;
	//Veg veg=new Veg();
	
	public Veg() {
		super();
		
	}
	
	public Veg(String vegToppings, int id) {
		super();
		this.vegToppings = vegToppings;
		this.id = counter++;
	}
	
	//public String getVegToppings() {
		
	//}
	
	public boolean validateType(String type) {
	
		if(type.equalsIgnoreCase("VegStuffed")||  type.equalsIgnoreCase("VegNotStuffed")) {
			System.out.println("is true" + type);
			return true;
		}
		return false;
		
		
	}
	
	public float identifyCost(String type,String size) {
		//validateType(type);
		//System.out.println(type);
		//validateSize(size);
		float cost=0;
		System.out.println("thes s");
		if(validateSize(size)==true && validateType()==true) {
		
			
			if(type.equalsIgnoreCase("VegStuffed") && size.equalsIgnoreCase("Small")) {
				 cost=30;
			}
			else if(type.equalsIgnoreCase("VegStuffed") && size.equalsIgnoreCase("Medium")) {
			
				 cost=60;
			}
			else if(type.equalsIgnoreCase("VegStuffed") && size.equalsIgnoreCase("Large")) {
				 cost=90;
			}
			else if(type.equalsIgnoreCase("VegNotStuffed") && size.equalsIgnoreCase("Small")) {
				 cost=20;
			}
			else if(type.equalsIgnoreCase("NonVegStuffed") && size.equalsIgnoreCase("Medium")) {
				 cost=40;
			}
			else if(type.equalsIgnoreCase("NonVegStuffed") && size.equalsIgnoreCase("Large")) {
				 cost=80;
			}
		
		}
		
		return cost ;
	} 
	
	public float calculateBillAmount() {
		validateCategory(category);
		float BillAmount=identifyCost()+(identifyCost()*5)/100;
		System.out.println(BillAmount);
		return BillAmount;
		
		
	}

	@Override
	public boolean validateType() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public float identifyCost() {
		// TODO Auto-generated method stub
		return 0;
	}


	

	
	
	

	
	
	

}
